# PT-ASM-REP-LP
# Landing Page Asimov 🎓

## Description
This repository contains the landing page for the asimov project

## Team CyberSoft 👨‍💻
* Gustavo Chavez Tecssi		    u201914306
* Erikc Anderson Cortez Benites	u201810133
* Jorgeluis Escobedo Mori	    u201924132
* Raquel Chavez Cruz		    u201914478


See [Landing Page deployed](https://tavoexe.github.io/Asimov-LandingPage/).